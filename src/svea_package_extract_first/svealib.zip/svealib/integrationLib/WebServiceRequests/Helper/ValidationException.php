<?php
namespace Svea;

/**
 * @author Anneli Halld'n, Daniel Brolund for Svea Webpay
 */
class ValidationException extends \Exception {  // \Exception referes to class Exception outside our \Svea\ namespace

}