<?php
namespace Svea;

class SveaRequest {

    public $request;

}
