<?php
namespace Svea;

/* * Variables:
 * IsCompany, CountryCode, SecurityNumber
 */

class SveaAddress {

    public $Auth;
    public $IsCompany;
    public $CountryCode;
    public $SecurityNumber;

}