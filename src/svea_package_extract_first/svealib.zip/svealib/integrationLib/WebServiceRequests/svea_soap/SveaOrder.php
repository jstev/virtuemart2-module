<?php
namespace Svea;

/**
 * Order object
 */
class SveaOrder {

    public $Auth;
    public $CreateOrderInformation;

}
