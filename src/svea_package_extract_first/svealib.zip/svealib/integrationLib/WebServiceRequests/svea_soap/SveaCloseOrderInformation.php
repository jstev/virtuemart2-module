<?php
namespace Svea;

/**
 * @author Anneli Halld'n, Daniel Brolund for Svea Webpay
 */
class SveaCloseOrderInformation {

    public $SveaOrderId;

}