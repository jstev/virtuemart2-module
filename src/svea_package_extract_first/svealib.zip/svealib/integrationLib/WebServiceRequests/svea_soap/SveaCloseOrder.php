<?php
namespace Svea;

/**
 * @author Anneli Halld'n, Daniel Brolund for Svea Webpay
 */
class SveaCloseOrder {

    public $Auth;
    public $CloseOrderInformation;

}