<?php
namespace Svea;

/**
 * Order object
 */
class SveaDeliverOrder {

    public $Auth;
    public $DeliverOrderInformation;

}
