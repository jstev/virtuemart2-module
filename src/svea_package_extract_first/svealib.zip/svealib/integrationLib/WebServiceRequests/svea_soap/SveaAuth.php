<?php
namespace Svea;

/**
 * Auth object, holder of
 * Username, Password, ClientNumber
 */
class SveaAuth {

    public $Username;
    public $Password;
    public $ClientNumber;

}