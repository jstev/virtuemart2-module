<?php
// DistributionType is excluded from the Svea namespace

/**
 *constants for InvoiceDistributionType
 *
 * @author anne-hal
 */
abstract class DistributionType {

    const POST = "Post";
    const EMAIL = "Email";
}
