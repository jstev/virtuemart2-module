<?php
namespace Svea;

class InvalidTypeException extends \Exception {  // \Exception referes to class Exception outside our \Svea\ namespace
}

