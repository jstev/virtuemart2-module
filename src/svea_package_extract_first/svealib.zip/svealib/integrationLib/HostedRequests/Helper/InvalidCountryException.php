<?php
namespace Svea;

class InvalidCountryException extends \Exception {  // \Exception referes to class Exception outside our \Svea\ namespace
}
